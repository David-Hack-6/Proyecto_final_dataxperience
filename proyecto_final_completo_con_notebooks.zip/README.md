# Proyecto Final: Análisis de Servidor Web

Este proyecto procesa datos de un servidor web, realiza limpieza, exploración y aplica un modelo de regresión lineal.

## Estructura
- `data/raw/`: Datos originales.
- `data/processed/`: Datos limpios.
- `scripts/`: Código en Python.
- `notebooks/`: Jupyter Notebooks para análisis.
- `figures/`: Gráficos generados.

## Requisitos
Instalar dependencias con:
```bash
pip install -r requirements.txt
```

## Ejecución rápida
1. Ejecuta los scripts de `scripts/` en orden: `limpieza.py`, `exploracion.py`, `modelo_regresion.py`.
2. Abre los notebooks en `notebooks/` para trabajar de forma interactiva.

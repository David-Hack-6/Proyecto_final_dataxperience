import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

df = pd.read_csv("data/processed/servidor_web_limpio.csv")

df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
X = df[['bytes', 'hour']]
y = df['response_time']

if 'status_code' in df.columns:
    X = pd.concat([X, pd.get_dummies(df['status_code'], prefix='status', drop_first=True)], axis=1)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
pred = model.predict(X_test)

mse = mean_squared_error(y_test, pred)
r2 = r2_score(y_test, pred)
print("MSE:", mse, "R2:", r2)

plt.figure()
plt.scatter(y_test, pred, alpha=0.3)
plt.xlabel("Response time real")
plt.ylabel("Response time predicho")
plt.title("Real vs Predicho")
plt.savefig("figures/real_vs_predicho.png", bbox_inches='tight')

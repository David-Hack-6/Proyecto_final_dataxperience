import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/processed/servidor_web_limpio.csv")

print(df.describe())

plt.figure()
df['response_time'].hist(bins=30)
plt.xlabel("Response Time")
plt.ylabel("Frecuencia")
plt.title("Distribución de Response Time")
plt.savefig("figures/distribucion_response_time.png", bbox_inches='tight')

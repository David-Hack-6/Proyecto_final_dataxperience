import pandas as pd

df = pd.read_csv("data/raw/servidor_web.csv")

print('Dimensiones:', df.shape)
print(df.info())
print(df.head())

print("Valores nulos por columna:\n", df.isna().sum())
print('Duplicados:', df.duplicated().sum())

df = df.drop_duplicates()
df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
df = df.dropna(subset=['timestamp'])
df = df[df['response_time'] >= 0]

df.to_csv("data/processed/servidor_web_limpio.csv", index=False)
print("Dataset limpio guardado en data/processed/")
